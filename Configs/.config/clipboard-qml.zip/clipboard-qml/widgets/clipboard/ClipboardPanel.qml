import QtQuick
import QtQuick.Layouts
import qs.widgets.clipboard

Rectangle {
    id: panel

    width: 1000
    height: 260
    radius: 28
    color: "#0d0d0d"
    border.width: 1
    border.color: "#2a2a2a"

    property int activeTab: 0

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 20
        spacing: 16

        // ── top row: brand, search, right icons ──────────────────────
        RowLayout {
            Layout.fillWidth: true
            spacing: 14

            Text {
                text: "\uf179" // apple logo (nerd font / font awesome brand glyph)
                color: "#ffffff"
                font.pixelSize: 17
            }

            Text {
                text: "Supaste"
                color: "#ffffff"
                font.pixelSize: 15
                font.weight: Font.DemiBold
            }

            Item { Layout.fillWidth: true }

            Text {
                text: "\uf002"
                color: "#7a7a7a"
                font.pixelSize: 14
            }

            Rectangle {
                width: 240
                height: 30
                radius: 15
                color: "#1a1a1a"
                visible: false // search input lives inline below instead
            }

            Text {
                text: "\uf005" // star
                color: "#7a7a7a"
                font.pixelSize: 14
            }
            Text {
                text: "\uf00a" // grid
                color: "#7a7a7a"
                font.pixelSize: 14
            }
            Text {
                text: "\uf14d" // external link / expand
                color: "#7a7a7a"
                font.pixelSize: 14
            }

            Rectangle { width: 1; height: 18; color: "#2a2a2a" }

            Text {
                text: "\uf002"
                color: "#e0e0e0"
                font.pixelSize: 13
            }
            Text {
                text: "\uf1eb" // wifi
                color: "#e0e0e0"
                font.pixelSize: 13
            }
            Text {
                text: "09:41"
                color: "#e0e0e0"
                font.pixelSize: 13
                font.weight: Font.Medium
            }
        }

        // ── search input row ──────────────────────────────────────────
        RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Text {
                text: "\uf002"
                color: "#6e6e6e"
                font.pixelSize: 14
            }
            Text {
                text: "Search..."
                color: "#6e6e6e"
                font.pixelSize: 14
            }
            Item { Layout.fillWidth: true }
        }

        // ── category tabs ─────────────────────────────────────────────
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            CategoryTab { label: "History"; count: 24; active: panel.activeTab === 0; onClicked: panel.activeTab = 0 }
            CategoryTab { label: "Prompts"; count: 24; active: panel.activeTab === 1; onClicked: panel.activeTab = 1 }
            CategoryTab { label: "Colors"; count: 24; active: panel.activeTab === 2; onClicked: panel.activeTab = 2 }
            CategoryTab { label: "Assets"; count: 24; active: panel.activeTab === 3; onClicked: panel.activeTab = 3 }
            CategoryTab { label: "Inspirations"; count: 24; active: panel.activeTab === 4; onClicked: panel.activeTab = 4 }

            Rectangle {
                width: 30; height: 30; radius: 15
                color: "transparent"
                border.width: 1
                border.color: "#3a3a3a"
                Text {
                    anchors.centerIn: parent
                    text: "+"
                    color: "#9a9a9a"
                    font.pixelSize: 15
                }
            }

            Item { Layout.fillWidth: true }
        }

        // ── card row ───────────────────────────────────────────────────
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10

            ClipboardCard {
                Layout.preferredWidth: 145
                Layout.fillHeight: true
                thumbColor: "#3a3d2e"
                thumbImage: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400"
                showOverlayText: true
                title: "A useful Dock for live widgets"
                metaText: "dock.cool"
                sourceIcon: ""
                sourceIconColor: "#4285f4"
                Text {
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    anchors.margins: 8
                    text: "23 min ago"
                    color: "#9a9a9a"
                    font.pixelSize: 9
                }
            }

            ClipboardCard {
                Layout.preferredWidth: 145
                Layout.fillHeight: true
                thumbColor: "#4a3626"
                thumbImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400"
                showOverlayText: false
                metaText: "5 min ago"
                sourceIconColor: "#fbbc04"
                Text {
                    anchors.right: parent.right
                    anchors.bottom: parent.bottom
                    anchors.margins: 8
                    text: "3.5 MB"
                    color: "#9a9a9a"
                    font.pixelSize: 9
                }
            }

            ClipboardCard {
                Layout.preferredWidth: 145
                Layout.fillHeight: true
                thumbColor: "#f2f2f0"
                showOverlayText: false
                metaText: "23 min ago"
                sourceIconColor: "#4285f4"

                Column {
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 10
                    spacing: 4

                    Text {
                        width: parent.width
                        text: "A curated shelf of"
                        color: "#1a1a1a"
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                        wrapMode: Text.WordWrap
                    }
                    Text {
                        width: parent.width
                        text: "\uf179 macOS apps."
                        color: "#4a4a4a"
                        font.pixelSize: 9.5
                        wrapMode: Text.WordWrap
                    }
                    Text {
                        width: parent.width
                        text: "macapp.supply"
                        color: "#8a8a8a"
                        font.pixelSize: 9
                    }
                }

                Rectangle {
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 10
                    width: 34
                    height: 34
                    radius: 8
                    color: "#e8e8e5"
                    border.width: 1
                    border.color: "#d5d5d0"
                    Text {
                        anchors.centerIn: parent
                        text: "\uf109"
                        font.pixelSize: 14
                        color: "#3a3a3a"
                    }
                }
            }

            ClipboardCard {
                Layout.preferredWidth: 145
                Layout.fillHeight: true
                thumbColor: "#1c1c1c"
                showOverlayText: false
                metaText: "19 min ago"
                sourceIconColor: "#4285f4"

                Column {
                    anchors.left: parent.left
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.margins: 10
                    spacing: 2

                    Text {
                        width: parent.width
                        text: "Minneapolis 55410,"
                        color: "#f0f0f0"
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                        wrapMode: Text.WordWrap
                    }
                    Text {
                        width: parent.width
                        text: "2941 Rocket Drive"
                        color: "#f0f0f0"
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                        wrapMode: Text.WordWrap
                    }
                    Text {
                        width: parent.width
                        text: "United States"
                        color: "#f0f0f0"
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                        wrapMode: Text.WordWrap
                    }
                }
            }

            ClipboardCard {
                Layout.preferredWidth: 145
                Layout.fillHeight: true
                thumbColor: "#0080ff"
                showOverlayText: false
                metaText: "35 min ago"
                sourceIconColor: "#ffffff"

                Text {
                    anchors.left: parent.left
                    anchors.bottom: parent.bottom
                    anchors.margins: 10
                    anchors.bottomMargin: 26
                    text: "#0080FF"
                    color: "#ffffff"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                }
            }
        }
    }
}
