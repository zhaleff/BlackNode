import QtQuick

Rectangle {
    id: card

    property string thumbColor: "#2a2a2a"
    property string thumbImage: ""
    property string title: ""
    property string subtitle: ""
    property string metaText: ""
    property string sourceIcon: ""
    property string sourceIconColor: "#4285f4"
    property bool showOverlayText: false

    radius: 16
    color: thumbColor
    clip: true

    Image {
        anchors.fill: parent
        source: card.thumbImage
        fillMode: Image.PreserveAspectCrop
        visible: card.thumbImage !== ""
    }

    // dark gradient scrim for overlay text (used on the photo/image cards)
    Rectangle {
        visible: card.showOverlayText
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        height: parent.height * 0.55
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#00000000" }
            GradientStop { position: 1.0; color: "#cc000000" }
        }
    }

    Column {
        visible: card.showOverlayText && card.title !== ""
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 10
        anchors.bottomMargin: 26
        spacing: 2

        Text {
            width: parent.width
            text: card.title
            color: "#ffffff"
            font.pixelSize: 12
            font.weight: Font.DemiBold
            wrapMode: Text.WordWrap
        }
        Text {
            width: parent.width
            text: card.subtitle
            color: "#cccccc"
            font.pixelSize: 10
            wrapMode: Text.WordWrap
            visible: card.subtitle !== ""
        }
    }

    // plain (non-overlay) title block, used for the text/address style card
    Column {
        visible: !card.showOverlayText && card.title !== ""
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 10
        spacing: 3

        Text {
            width: parent.width
            text: card.title
            color: "#f2f2f2"
            font.pixelSize: 11
            font.weight: Font.DemiBold
            wrapMode: Text.WordWrap
        }
    }

    // footer meta row: source favicon dot + label + right-aligned size/time
    Item {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 8
        height: 16

        Row {
            anchors.left: parent.left
            spacing: 5

            Rectangle {
                width: 14
                height: 14
                radius: 4
                color: card.sourceIconColor
                anchors.verticalCenter: parent.verticalCenter
            }

            Text {
                text: card.metaText
                color: "#bdbdbd"
                font.pixelSize: 9.5
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }
}
