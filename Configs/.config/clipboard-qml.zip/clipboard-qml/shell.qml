import QtQuick
import Quickshell
import qs.widgets.clipboard

ShellRoot {
    Scope {
        Variants {
            model: Quickshell.screens

            Item {
                required property var modelData

                PanelWindow {
                    implicitWidth: Screen.width
                    implicitHeight: 320
                    color: "transparent"
                    anchors.top: true
                    anchors.left: true
                    anchors.right: true
                    exclusiveZone: 0

                    ClipboardPanel {
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: parent.top
                        anchors.topMargin: 12
                    }
                }
            }
        }
    }
}
